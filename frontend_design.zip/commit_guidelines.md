# 📘 COMMIT_GUIDELINES

AI Mental Wellness Backend

---

# Purpose

This document defines:

* Commit message standards
* Branching strategy
* Feature development workflow
* PR rules
* Code stability expectations

All contributors (human or agent) must follow this structure.

---

# Branching Strategy

We use a **feature-based branching model**.

## Main Branches

### `main`

* Production-ready
* Stable at all times
* Only merged via reviewed PR

### `develop`

* Integration branch
* All completed features merge here first
* Must always compile and run

---

## Feature Branch Naming

Format:

```
feature/<module-name>-<short-description>
```

Examples:

```
feature/auth-register-login
feature/chat-ai-pipeline
feature/mood-journal-tagging
feature/analytics-dashboard-engine
feature/encryption-layer
feature/crisis-detection
```

---

## Bug Fix Branch Naming

```
fix/<short-description>
```

Example:

```
fix/jwt-expiry-validation
fix/mood-duplicate-entry-check
```

---

## Refactor Branch Naming

```
refactor/<area>
```

Example:

```
refactor/ai-service-structure
```

---

# Development Workflow

For every feature:

1. Create new feature branch from `develop`
2. Implement feature completely
3. Test locally
4. Ensure no linting or runtime errors
5. Commit properly
6. Push branch
7. Create Pull Request → `develop`
8. Merge only after verification

Never commit directly to `main`.

---

# Commit Message Guidelines

We follow a structured commit format.

## Commit Format

```
<type>: <short summary>

<optional detailed description>
```

---

## Allowed Commit Types

| Type     | Usage                   |
| -------- | ----------------------- |
| feat     | New feature             |
| fix      | Bug fix                 |
| refactor | Code restructuring      |
| docs     | Documentation           |
| chore    | Setup / config          |
| test     | Adding tests            |
| security | Security improvements   |
| perf     | Performance improvement |

---

## Good Commit Examples

```
feat: implement JWT authentication system

feat: add AI chat pipeline with context memory

feat: implement mood journal AI tagging

security: add AES-256 encryption for chat storage

fix: prevent duplicate daily mood entries

refactor: restructure chat service into modular functions

docs: add backend plan documentation
```

---

## Bad Commit Examples (Never Do This)

```
update
changes
fixed stuff
minor edits
testing
final version
```

Commits must explain WHAT was done.

---

# Feature Completion Rule

A feature branch should only be merged when:

* All endpoints for that feature are implemented
* Validation is complete
* No TODO comments remain
* Tested via Postman
* No console.log debugging left
* Error handling implemented
* Input validation included

If incomplete → do NOT merge.

---

# Feature Commit Strategy

Large features must be committed in logical chunks.

Example for Auth Feature:

```
feat: create user model
feat: implement register endpoint
feat: implement login endpoint
feat: add JWT middleware
security: hash passwords with bcrypt
```

Do NOT combine entire feature into one giant commit.

---

# Security-Sensitive Commit Rules

Any commit that:

* Changes encryption
* Modifies auth
* Changes token logic
* Updates crisis detection

Must use:

```
security: <description>
```

Example:

```
security: implement token expiration validation
```

---

# Pre-Merge Checklist

Before merging to `develop`:

* Server runs without crash
* All routes tested
* No sensitive logs
* Environment variables not committed
* .env is in .gitignore
* No hardcoded secrets

Before merging to `main`:

* Entire backend tested end-to-end
* AI calls verified
* Encryption verified
* No debug routes left
* Rate limiting enabled

---

# Pull Request Guidelines

PR title format:

```
[Feature] Implement JWT Authentication
```

PR description must include:

* Summary of feature
* Endpoints added
* Models modified
* Security implications
* Testing performed

---

# What Is NOT Allowed

* Committing directly to main
* Force pushing to main
* Vague commit messages
* Unreviewed security changes
* Breaking develop branch
* Mixing multiple unrelated features in one branch

---

# Recommended Development Order

Features should be implemented in this order:

1. Core infrastructure
2. Authentication
3. Chat module
4. Crisis detection
5. Mood tracking
6. Analytics
7. Encryption
8. Export system
9. Security hardening

Each as separate feature branches.

---

# Versioning Strategy

Use semantic versioning.

```
v1.0.0 → Core backend stable
v1.1.0 → Mood analytics added
v1.2.0 → Encryption added
v2.0.0 → Voice integration
```

---

# Engineering Philosophy

* Small, meaningful commits
* One feature per branch
* No rushed merges
* Code must be readable
* Security is not optional
* Stability > speed
