# Serenity- A Mental Wellness App

# Backend Implementation Plan (Phased)
mongodb_clusture password: UXRQN8guOS3DaNSJ

---

## Objective

Build a secure, modular, privacy-first backend system that supports:

* JWT authentication
* AI-powered contextual chat
* Crisis detection system
* Manual + AI-inferred mood tracking
* Analytics dashboard
* Encrypted data storage
* Profile export capability

The system must be production-structured, scalable, and secure.

---

# Architecture Overview

**Tech Stack**

* Node.js + Express
* MongoDB (Mongoose)
* JWT Authentication
* OpenAI API
* AES-256 Encryption Layer
* Zod/Joi validation
* Rate limiting & security middleware

---

# PHASE 1 — Core Infrastructure Setup

## Goal:

Establish base project structure and foundational middleware.

### Tasks:

1. Initialize Node project
2. Install dependencies:

   * express
   * mongoose
   * dotenv
   * bcrypt
   * jsonwebtoken
   * axios
   * zod or joi
   * helmet
   * cors
   * express-rate-limit
3. Create folder structure:

```
src/
  controllers/
  routes/
  models/
  services/
  middleware/
  utils/
  config/
```

4. Configure:

   * MongoDB connection
   * Environment variables
   * Centralized error handler
   * Request logger
   * Rate limiter
   * CORS
   * Helmet security

### Deliverable:

Server running with structured architecture and MongoDB connected.

---

# PHASE 2 — Authentication System

## Goal:

Implement secure JWT-based authentication.

### Tasks:

1. Create User model:

   * email
   * passwordHash
   * createdAt
   * lastLogin

2. Implement:

   * Register endpoint
   * Login endpoint
   * Refresh token endpoint

3. Use:

   * bcrypt for password hashing
   * Access token (15 min expiry)
   * Refresh token (7 days expiry)

4. Build `authMiddleware`:

   * Verify JWT
   * Attach user to request

5. Input validation on all auth routes.

### Deliverable:

Fully working auth system with token protection.

---

Good. Now we’re designing this properly.

Below is a rewritten **`BACKEND_DEVELOPMENT_PLAN.md` (Phase 3 onward)** structured for:

* Layered memory architecture
* Vertical feature development
* Backend + frontend integration blocks
* Incremental complexity
* No overengineering

This version assumes:
Phase 1 (Infra) ✅
Phase 2 (Auth) ✅

Everything below is redesigned around your memory-layer system.

---

# 📘 BACKEND_DEVELOPMENT_PLAN.md

## Phase 3 Onward — Layered Memory Architecture + Vertical Development

---

# 🧠 Architectural Direction

From Phase 3 onward, the system follows:

## Memory Layers

1. **Session Memory (Short-Term)**

   * Active conversation messages
   * Limited to last 10–15 exchanges
   * Used only during session

2. **Daily Structured Memory**

   * One structured TL;DR per day
   * AI-generated summary
   * Emotion + tags + mood averages

3. **Pattern Memory (Long-Term)**

   * Aggregated emotional trends
   * Recurring stressors
   * Behavioral correlations

The AI provider never permanently stores user memory.
Memory is reconstructed per session.

Development from this point will follow **vertical feature blocks**:
Backend feature + frontend integration before moving deeper.

---

# 🔹 PHASE 3 — Core Chat Engine + Session Memory

## 🎯 Goal

Build stable AI interaction pipeline with emotional metadata.

This is the first vertical feature block.

---

## Backend Tasks

### 1️⃣ Create Chat Models

**ChatSession**

* userId
* createdAt
* lastActive

**ChatMessage**

* sessionId
* role (user | assistant)
* encryptedContent
* inferredEmotion
* moodScore
* timestamp

---

### 2️⃣ Chat Pipeline Service

Create `chatService.js`:

Flow:

```
Incoming message
→ Crisis detection
→ Emotion inference
→ Fetch last 10–15 session messages
→ Construct prompt
→ Call AI
→ Encrypt response
→ Store both messages
→ Return assistant response
```

---

### 3️⃣ Crisis Detection

* Rule-based keyword detection
* Severity threshold
* Override AI response if triggered

---

### 4️⃣ Emotion Inference

On every user message:

* Classify emotion
* Assign mood score (1–5)
* Store metadata

No long-term aggregation yet.

---

### 5️⃣ Prompt Construction (Phase 3 Version)

Inject only:

* System prompt
* Last session messages
* Current message

No daily memory.
No pattern memory.

---

## Frontend Integration (Block 1)

Build minimal UI:

* Login screen
* Chat screen
* Message bubbles
* Loading indicator
* Basic mood indicator display

Goal:
User can log in and talk to AI.

---

## Phase 3 Completion Criteria

* Stable chat endpoint
* Crisis detection tested
* Emotion metadata stored
* Frontend chat fully usable

Only then proceed.

---

# 🔹 PHASE 4 — Daily Structured Memory Engine

## 🎯 Goal

Transform raw interactions into structured daily summaries.

---

## Backend Tasks

### 1️⃣ Create DailyMemory Model

Fields:

* userId
* date
* summary
* dominantEmotion
* averageMoodScore
* tags
* keyStressors
* createdAt

One entry per day.

---

### 2️⃣ Daily Aggregation Service

Trigger options:

* Cron job at midnight
  OR
* First interaction next day

Flow:

```
Fetch all messages + journal entries for date
→ Aggregate emotional metadata
→ Send summary request to AI
→ Receive structured JSON
→ Store DailyMemory
```

AI must return structured JSON format only.

---

### 3️⃣ Safeguards

* Prevent duplicate daily memory
* Encrypt summary at rest

---

## Frontend Integration (Block 2)

Add:

* Daily summary card
* Basic calendar view
* View summary details

Goal:
User sees daily TL;DR.

---

## Phase 4 Completion Criteria

* One DailyMemory per day
* Structured output stored
* Frontend displays daily summary

---

# 🔹 PHASE 5 — Pattern Memory Engine (Long-Term Trends)

## 🎯 Goal

Aggregate DailyMemory into behavioral insights.

---

## Backend Tasks

### 1️⃣ Create UserPatternMemory Model

Fields:

* userId
* baselineMood
* recurringTags
* dominantEmotionTrend
* moodTrendDirection
* correlationInsights
* lastUpdated

---

### 2️⃣ Pattern Analysis Service

Functions:

* calculateBaselineMood()
* detectRecurringTags()
* calculateTrendSlope()
* detectTagMoodCorrelation()

---

### 3️⃣ Update Strategy

PatternMemory updates:

* When new DailyMemory created
  OR
* Weekly scheduled recalculation

---

## Frontend Integration (Block 3)

Add dashboard:

* Weekly mood graph
* Trend indicator
* Most frequent stressor
* Dominant emotion

Goal:
User sees meaningful patterns.

---

## Phase 5 Completion Criteria

* PatternMemory stored
* Dashboard displays aggregated insights
* No raw chat scanning at dashboard level

---

# 🔹 PHASE 6 — Selective Memory Retrieval (Lightweight RAG)

## 🎯 Goal

Inject only relevant memory into AI prompt.

---

## Backend Tasks

### 1️⃣ Retrieval Logic

On new message:

* Extract keywords
* Compare with recurringTags
* Identify relevant DailyMemory summaries
* Select top relevant memory pieces

---

### 2️⃣ Prompt Construction (Phase 6 Version)

Inject:

```
System prompt
+
Relevant Pattern Memory
+
Recent DailyMemory
+
Last session messages
+
Current message
```

Token-efficient and contextual.

---

## Frontend Integration

No UI change required.
But test conversational improvement.

---

## Phase 6 Completion Criteria

* Context-aware injection working
* No excessive token usage
* Conversations feel personalized

---

# 🔹 PHASE 7 — Encryption Hardening

## 🎯 Goal

Full privacy alignment.

---

Encrypt at rest:

* ChatMessage content
* DailyMemory summary
* Journal notes

Key management:

* Per-user derived key
* Secure environment storage

Frontend:

* Store encrypted DailyMemory cache
* Never store plaintext sensitive memory

---

## Completion Criteria

* No plaintext sensitive storage
* Verified encryption/decryption flow

---

# 🔹 PHASE 8 — Journal & Mood Integration Unification

## 🎯 Goal

Unify journal entries into memory pipeline.

---

Journal flow:

User writes journal
→ Emotion inference
→ Tag extraction
→ Stored as MoodEntry
→ Included in daily aggregation

Manual mood tracking feeds:

* DailyMemory
* PatternMemory

---

# 🔹 PHASE 9 — Export & Data Portability

User can export:

* DailyMemory
* PatternMemory
* Mood history
* Chat history (optional)

Formats:

* JSON
* Encrypted archive

---

# 🧠 Development Strategy Rules

1. Do not implement Phase 4 until Phase 3 stable with frontend.
2. Always build backend + frontend in vertical slices.
3. No premature optimization.
4. No full memory injection before retrieval logic built.
5. Each phase must have:

   * Feature branch
   * Logical commits
   * Pull request to develop

---

# 🏗 Final Architecture Overview

| Layer            | Purpose                       |
| ---------------- | ----------------------------- |
| Session Memory   | Active chat context           |
| DailyMemory      | Structured daily TL;DR        |
| PatternMemory    | Long-term behavioral insights |
| Retrieval Engine | Selective context injection   |
| Encryption Layer | Privacy protection            |

This is no longer just a GPT wrapper.

It is a structured cognitive memory system.

---

# ⚠️ Critical Discipline

If you try to implement:

* Pattern engine
* Retrieval logic
* Encryption
* Analytics

All at once,

You will stall.

Build:
Chat → Summary → Pattern → Retrieval → Hardening.

One layer at a time.

