📘 FRONTEND_DESIGN.md

Serenity — Frontend Design System & UX Architecture

🎯 Product Vision

Serenity is not a productivity app.
It is a calm cognitive companion.

Design must reflect:

Soft trust

Emotional safety

Minimal friction

Zero overwhelm

High clarity

No clutter. No aggressive colors. No noise.

🎨 Design Language
1️⃣ Visual Identity

From your prototype:

Primary: #36e236 (soft vitality green)

Sage, lavender, cream backgrounds

Glassmorphism overlays

Soft blurred background blobs

Rounded corners (lg / xl / 2xl)

This works.

It communicates:

Growth

Stability

Warmth

Do NOT introduce harsh contrast later.

2️⃣ Core UI Principles
Calm Hierarchy

One primary focus per screen

Avoid dense information clusters

Emotional Feedback

Mood score ring
Soft glow
Animated AI indicator

Organic Transitions

Subtle fade-ins
Scale transitions
No sharp modal jumps

🧠 UX Philosophy (Aligned With Memory Architecture)

Because backend now uses:

Session memory

DailyMemory

PatternMemory

Frontend must:

Never expose raw complexity

Show distilled insight

Keep user focused on experience, not system mechanics

📱 Screen-Level Design Intent
🏠 Home Dashboard

Purpose:

Emotional overview

Quick AI entry

Today’s state snapshot

Sections:

Greeting (Personalized)

Mood Score Ring

Derived from DailyMemory + PatternMemory

AI Guide Prompt

Recent Journal Preview

Must feel:

Encouraging

Stable

Warm

🤖 AI Interaction Screen

Purpose:

Emotional venting

Guided reflection

Grounding exercises

Design Implications:

Breathing avatar animation = system empathy

Quick-reply chips = frictionless support

No visible memory indicators

Important:
AI memory injection must feel invisible.

User must feel:

“It understands me.”

Not:

“It is calculating patterns.”

📓 Journal Screen

Purpose:

Emotional externalization

Structured self-reflection

Must support:

Tagging

Emotion labeling

Quick scanning

Clean search

No complex UI elements.

Clarity > features.

📊 Insights Screen

Purpose:

Show PatternMemory visually

Components:

Mood fluctuation graph

Top moods

AI-generated insight summary

Very important:
Insights must feel gentle.

Avoid:

Harsh red dips

Alarm-style warnings

We guide, not judge.

👤 Profile Screen

Purpose:

Account

Privacy

Data export

Encryption transparency

Eventually add:

“Download My Data”

“Delete My Data”

Trust is everything in mental health tech.

🎨 Component Design System

Reusable components:

GlassCard

MoodRing

TagChip

InsightCard

AIMessageBubble

UserMessageBubble

QuickReplyChip

FloatingActionButton

BottomNav

Everything must be modular for Expo conversion.

🌗 Dark Mode Philosophy

Dark mode must:

Reduce contrast

Maintain warmth

Avoid neon glow

Primary green should soften in dark mode.

🔐 Privacy Design Cues

You must subtly communicate:

Data encrypted

AI does not permanently store memory

User controls export

But never overwhelm with technical details.

🎯 Emotional UX Goal

If user opens the app during stress:

They should feel:

Slower breathing

Lower cognitive load

Emotional validation

That’s your design benchmark.